# MessageHelper — Upwork

Translate Upwork messages and polish message or feedback drafts through MacHelper.

1. Install and open MacHelper on your Mac.
2. Download and unzip the browser extension source.
3. Open chrome://extensions or edge://extensions and enable Developer mode.
4. Choose Load unpacked and select the extracted MessageHelper-Upwork folder.
5. Open the extension settings and check the connection to MacHelper. Only you send messages or submit feedback.

Complete source: https://github.com/bosstwobread/LocalAIBaseTools/tree/main/Extensions/MessageHelper-Upwork
